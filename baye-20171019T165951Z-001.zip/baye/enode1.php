<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$tx_power = $_POST['tx_power'];
$antenna_gain = $_POST['antenna_gain'];
$enodeb_sensitivity = $_POST['enodeb_sensitivity'];
$noise_figure = $_POST['noise_figure'];
$cable_loss = $_POST['cable_loss'];
$interference_margin = $_POST['interference_margin'];
$mha_gain = $_POST['mha_gain'];


if($site_name && $tx_power && $antenna_gain && $enodeb_sensitivity && $noise_figure && $cable_loss && $interference_margin && $mha_gain){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM enodeb_parameters WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "The site name already exist! Please enter different site name";
				header("Location: enodeB_para.php");

				#mysql_query("INSERT INTO enodeb_parameters(site_name, tx_power, antenna_gain, enodeb_sensitivity,  noise_figure, cable_loss, interference_margin, mha_gain) VALUES('$site_name','$tx_power','$antenna_gain','$enodeb_sensitivity','$noise_figure','$cable_loss','$interference_margin','$mha_gain')");
				#$registered = mysql_affected_rows();
				#header("Location: other_para.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO enodeb_parameters(site_name, tx_power, antenna_gain, enodeb_sensitivity,  noise_figure, cable_loss, interference_margin, mha_gain) VALUES('$site_name','$tx_power','$antenna_gain','$enodeb_sensitivity','$noise_figure','$cable_loss','$interference_margin','$mha_gain')");
				$registered = mysql_affected_rows();
				header("Location: other_para.php");
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>