<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$traffic_ratio_ul = $_POST['traffic_ratio_ul'];
$traffic_ratio_dl = $_POST['traffic_ratio_dl'];
$ul_bh_data_traffic = $_POST['ul_bh_data_traffic'];
$dl_bh_data_traffic = $_POST['dl_bh_data_traffic'];
$average_traffic_ratio = $_POST['average_traffic_ratio'];
$number_subscriber_enodeb = $_POST['number_subscriber_enodeb'];
$subscriber_number = $_POST['subscriber_number'];


if($site_name && $traffic_ratio_ul && $traffic_ratio_dl && $ul_bh_data_traffic && $dl_bh_data_traffic && $average_traffic_ratio && $number_subscriber_enodeb){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM s1_x2 WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "Name already registered! Please type another name ";
				header("Location: s1_x2.php");
			}else{
				mysql_query("INSERT INTO s1_x2(site_name, traffic_ratio_ul, traffic_ratio_dl, ul_bh_data_traffic, dl_bh_data_traffic, average_traffic_ratio, number_subscriber_enodeb) VALUES('$site_name','$traffic_ratio_ul','$traffic_ratio_dl','$ul_bh_data_traffic','$dl_bh_data_traffic','$average_traffic_ratio','$number_subscriber_enodeb')");
				$registered = mysql_affected_rows();
				header("Location: solution.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>