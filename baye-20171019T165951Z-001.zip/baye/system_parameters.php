<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
	<body style="background-image: url('images/background1.png')">
		<header class="page-header" style="background-color: rgb(45, 87, 39),">
			<div class = "container">
				<img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
				<h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
				<img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
			</div>

		</header>
	<nav id="top-menu" style="background-color:#cce; height:130px">
			<center>
			    <ul>
			        <li> <a class="btn waves-effect waves-light" href="system_parameters.php">System parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="user_equip.php">UE parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="enodeB_para.php">eNodeB parameter</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="other_para.php">Other Parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="propagation_para.php">Propagation </a> </li>
			        <li> <a class="btn waves-effect waves-light" href="coverage.php">Coverage Caculations parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="capacity.php">Capacity Planning parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="s1_x2.php">S1 and X2 Parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="solution.php">solutions</a> </li>
			    </ul>
		</center>
	</nav>
	
		<div class="container">
			<center>
				<h1 style="color:#cab">System Parameters</h1>
			</center>
			<form class="container" method="post" action="system1.php" style="background-color:#fff">
				<table name ="system" style="border:9px #fac; border-padding:14px; border-radius:6px; background-color:#fff">
					<tr>
						<td>
							Name of Site
						</td>
						<td>
							<input type="text" name="site_name">
						</td>
					</tr>
					<tr style="border:8px; ">
						<td>
							Operating Frequency (MHz)
						</td>
						<td>
							<select class="browser-default" style="border: 8px" name="ope_freq" id="ope_freq" >
								<option value="700" name="700">700</option>
								<option value="800" name="800">800</option>
								<option value="900" name="900">900</option>
								<option value="1800" name="1800">1800</option>
								<option value="1900" name="1900">1900</option>
								<option value="2100" name="2100">2100</option>
								<option value="2600" name="2600">2600</option>

							</select>

						</td>

					</tr>
					<tr>
						<td>
							Bandwidth(MHz)
						</td>
						<td>
							<select class="browser-default" name="bandwidth" id="bandwidth">
								<option value="1.4">1.4</option>
								<option value="3">3</option>
								<option value="5">5</option>
								<option value="10">10</option>
								<option value="15">15</option>
								<option value="20">20</option>

							</select>
						</td>

					</tr>
					<tr>
						<td>Cluster Type</td>
						<td>
							<select class="browser-default" name="cluster" id="cluster">
								<option value="Rural">Rural</option>
								<option value="Suburban">Suburban</option>
								<option value="Urban">Urban</option>
								<option value="Dense Urban">Dense Urban</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							Cell edge throughput DL(Kbps)
						</td>
						<td>
							<input type="text" name="DL">
						</td>
					</tr>
					<tr>
						<td>
							Cell edge throughput UL(Kbps)
						</td>
						<td>
							<input type="text" name="UL">
						</td>
					</tr>
					<tr>
						<td>
							Cell edge MCS-DL
						</td>
						<td>
							<select class="browser-default" name="downlink" id="downlink">
								<option value="QPSK-25%">QPSK-25%</option>
								<option value="QPSK-50%">QPSK-50%</option>
								<option value="QPSK-75%">QPSK-75%</option>
								<option value="QPSK-100%">QPSK-100%</option>
								<option value="16QAM-25%">16QAM-25%</option>
								<option value="16QAM-50%">16QAM-50%</option>
								<option value="16QAM-75%">16QAM-75%</option>
								<option value="16QAM-100%">16QAM-100%</option>
								<option value="64QAM-25%">64QAM-25%</option>
								<option value="64QAM-50%">64QAM-50%</option>
								<option value="16QAM-75%">16QAM-75%</option>
								<option value="64QAM-100%">64QAM-100%</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							Cell edge MCS-UL
						</td>
						<td>
							<select class="browser-default" name="uplink" id="uplink">
								<option value="QPSK-25%">QPSK-25%</option>
								<option value="QPSK-50%">QPSK-50%</option>
								<option value="QPSK-75%">QPSK-75%</option>
								<option value="QPSK-100%">QPSK-100%</option>
								<option value="16QAM-25%">16QAM-25%</option>
								<option value="16QAM-50%">16QAM-50%</option>
								<option value="16QAM-75%">16QAM-75%</option>
								<option value="16QAM-100%">16QAM-100%</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							Channel Mode
						</td>
						<td>
							<select class="browser-default" name="channel_mode" id="channel_mode">
								<option value="EPA5">EPA5</option>
								<option value="ETU70">ETU70</option>
								<option value="ETU3">ETU3</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							 Downlink-Antenna Technique
						</td>
						<td>
							<select class="browser-default" name="DL_antenna" id="DL_antenna">
								<option value="MIMO 2*2">MIMO 2*2</option>
								<option value="1Tx-2Rx(MRC)">1Tx-2Rx(MRC)</option>
								<option value="2Tx-2Rx(TxDiv)">2Tx-2Rx(TxDiv)</option>
								<option value="2Tx-2Rx(SM)">2Tx-2Rx(SM)</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							 Uplink-Antenna Technique
						</td>
						<td>
							<select class="browser-default" name="UL_antenna" id="UL_antenna">
								<option value="MIMO 2*2">MIMO 2*2</option>
								<option value="1Tx-2Rx(MRC)">1Tx-2Rx(MRC)</option>
								<option value="2Tx-2Rx(TxDiv)">2Tx-2Rx(TxDiv)</option>
								<option value="2Tx-2Rx(SM)">2Tx-2Rx(SM)</option>
							</select>
						</td>
					</tr>
				</table>
				<center>
				<h2><input type="submit" name="submit" value="Save"/></h2>
			</center>
			</form>
			<center>
				<a class="btn waves-effect waves-light" href="user_equip.php">Next</a>
			</center>

		</div>
		<footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
			<div class="footer-copyright">
				<div class="container">
					<center>
						&copy; Copyright 2016

					</center>

				</div>

			</div>
		</footer>
	</body>
</html>