<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
	<body style="background-image: url('images/background1.png')">
		<header class="page-header" style="background-color: rgb(45, 87, 39),">
			<div class = "container">
				<img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
				<h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
				<img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
			</div>

		</header>
		<nav id="top-menu" style="background-color:#cce; height:130px">
			<center>
			    <ul>
			        <li> <a class="btn waves-effect waves-light" href="system_parameters.php">System parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="user_equip.php">UE parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="enodeB_para.php">eNodeB parameter</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="other_para.php">Other Parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="propagation_para.php">Propagation </a> </li>
			        <li> <a class="btn waves-effect waves-light" href="coverage.php">Coverage Caculations parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="capacity.php">Capacity Planning parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="s1_x2.php">S1 and X2 Parameters</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="solution.php">solutions</a> </li>
			    </ul>
		</center>
	</nav>
		<div class="container" style="background-color:#fff">
			<div class="container">
				<center>
					<h1>
						UE Parameters
					</h1>
				</center>
			</div>
			<form class="container" method="post" action="user_equip1.php" >
				<table>
					<tr>
						<td>
							Name of Site
						</td>
						<td>
							<input type="text" name="site_name">
						</td>
					</tr>
					<tr>
						<td>
							Maximum Tx Power (dBm)
						</td>
						<td>
							<select class="browser-default" name="tx_power">
								<option value="33">Class1(33dBm)</option>
								<option value="27">Class2(27dBm)</option>
								<option value="24">Class3(24dBm)</option>
								<option value="23">Class4(23dBm)</option>
								<option value="21">Class5(21dBm)</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>
							 Antenna Gain (dBi)
						</td>
						<td>
							<input type"text" name="antenna_gain">
						</td>
					</tr>
					<tr>
						<td>
							 UE Sensitivity (dBm)
						</td>
						<td>
							<input type"text" name="ue_sensitivity">
						</td>
					</tr>
					<tr>
						<td>
							Body loss (dB) **It is always a Negative value
						</td>
						<td>
							<input type"text" name="body_loss">
						</td>
					</tr>
					<tr>
						<td>
							Noise Figure (dB)
						</td>
						<td>
							<input type"text" name="noise_figure">
						</td>
					</tr>
					<tr>
						<td>
							Control Channel Overhead (dB)
						</td>
						<td>
							<input type"text" name="ue_gain">
						</td>
					</tr>
					<tr>
						<td>
							 Interference Margin (dB)
						</td>
						<td>
							<input type"text" name="interference_margin">
						</td>
					</tr>
				</table>
				<center>
				<h2><input type="submit" name="submit" value="Save"/></h2>
			</center>
			</form>
		</div>
		<footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
			<div class="footer-copyright">
				<div class="container">
					<center>
						&copy; Copyright 2016

					</center>

				</div>

			</div>
		</footer>
	</body>
</html>