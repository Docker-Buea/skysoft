<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$cell_edge = $_POST['cell_edge'];
$downlink_cell_load = $_POST['downlink_cell_load'];
$uplink_cell_load = $_POST['uplink_cell_load'];
$penetration_loss = $_POST['penetration_loss'];
$dl_other_gain_loss = $_POST['dl_other_gain_loss'];
$ul_other_gain_loss = $_POST['ul_other_gain_loss'];


if($site_name && $cell_edge && $downlink_cell_load && $uplink_cell_load && $penetration_loss && $dl_other_gain_loss && $ul_other_gain_loss){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM other_parameters WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "Name already registered! Please type another name ";
				header("Location: other_para.php");

				#mysql_query("INSERT INTO other_parameters(site_name, cell_edge, downlink_cell_load, uplink_cell_load,  penetration_loss, dl_other_gain_loss, ul_other_gain_loss) VALUES('$site_name','$cell_edge','$downlink_cell_load','$uplink_cell_load','$penetration_loss','$dl_other_gain_loss','$ul_other_gain_loss')");
				#$registered = mysql_affected_rows();
				#header("Location: propagation_para.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO other_parameters(site_name, cell_edge, downlink_cell_load, uplink_cell_load,  penetration_loss, dl_other_gain_loss, ul_other_gain_loss) VALUES('$site_name','$cell_edge','$downlink_cell_load','$uplink_cell_load','$penetration_loss','$dl_other_gain_loss','$ul_other_gain_loss')");
				$registered = mysql_affected_rows();
				header("Location: propagation_para.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>