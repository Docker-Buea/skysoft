<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
<body style="background-image: url('images/background1.png')">
		<header class="page-header" style="background-color: rgb(45, 87, 39),">
			<div class = "container">
				<img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
				<h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
				<img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
			</div>

		</header>
	<nav id="top-menu" style="background-color:#cce; height:130px">
			<center>
			    <ul>
			        <li> <a class="btn waves-effect waves-light" href="downlink.php">Downlink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="uplink.php">Uplink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="up_down_link.php">Uplink and Downlink Capacity Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="s1_x2_solution.php">S1 and X2 dimensioning</a> </li>
			        
			    </ul>
		</center>
	</nav>
	<br><br>
	<div class="container" style="background-color:#fff" >
<?php
$site_name = $_POST['site_name'];

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT * FROM system_parameters WHERE site_name='$site_name'");
		$username2 = mysql_query("SELECT * FROM enodeb_parameters WHERE site_name='$site_name'");
		$username1 = mysql_query("SELECT * FROM ue_parameters WHERE site_name='$site_name'");
		$username3 = mysql_query("SELECT * FROM other_parameters WHERE site_name='$site_name'");
		$username4 = mysql_query("SELECT * FROM propagation_parameters WHERE site_name='$site_name'");
		$username5 = mysql_query("SELECT * FROM coverage WHERE site_name='$site_name'");
		$username6 = mysql_query("SELECT * FROM capacity WHERE site_name='$site_name'");

	echo "<table>";
	echo "<center> <h1> Uplink Link Budget and Coverage Calculations</h1> </center>";
		while ($row = mysql_fetch_array($username)) {
			$bandwidth = $row['bandwidth'];
			$operating_freq = $row['operating_freq'];
			$cluster_type = $row['cluster_type'];
			$cell_edge_DL = $row['cell_edge_DL'];
			$cell_edge_UL = $row['cell_edge_UL'];
			$downlink_MSC = $row['downlink_MSC'];
			$uplink_MSC = $row['uplink_MSC'];
			$channel_mode = $row['channel_mode'];
			$downlink_antenna = $row['downlink_antenna'];
			$uplink_antenna = $row['uplink_antenna'];
		}
		while ($row1 = mysql_fetch_array($username1)) {
			$ue_sensitivity = $row1['ue_sensitivity'];
			$ue_noise_figure = $row1['noise_figure'];
			$ue_control_channel = $row1['control_channel'];
			$ue_interference_margin = $row1['interference_margin'];
			$UE_tx_power = $row1['tx_power'];
			$UE_antenna_gain = $row1['antenna_gain'];
			$body_loss = $row1['body_loss'];
			$EIRP = $UE_tx_power + $UE_antenna_gain - $body_loss;
		}
		while ($row2 = mysql_fetch_array($username2)) {
			$e_tx_power = $row2['tx_power'];
			$e_antenna_gain = $row2['antenna_gain'];
			$e_enodeb_sensitivity = $row2['enodeb_sensitivity'];
			$e_noise_figure = $row2['noise_figure'];
			$e_cable_loss = $row2['cable_loss'];
			$e_interference_margin = $row2['interference_margin'];
			$e_mha_gain = $row2['mha_gain'];
			$thermal = (10 * log10(290 * 1.38*(exp(-23))* $bandwidth)) + 30;
			$receiver_noise = $thermal + $e_noise_figure;
			
		}
		while ( $row3 = mysql_fetch_array($username3)) {
			$cell_edge = $row3['cell_edge'];
			$uplink_cell_load = $row3['uplink_cell_load'];
			$downlink_cell_load = $row3['downlink_cell_load'];
			$penetration_loss = $row3['penetration_loss'];
			$ul_other_gain_loss = $row3['ul_other_gain_loss'];
			$dl_other_gain_loss = $row3['dl_other_gain_loss'];
			$signal_strnght = $e_enodeb_sensitivity - $e_antenna_gain + $e_cable_loss + $ul_other_gain_loss + $e_interference_margin;
			$MAPL = $EIRP + $e_antenna_gain + $e_mha_gain - $e_enodeb_sensitivity - $e_interference_margin - $e_cable_loss;
		}

		while ($row4 = mysql_fetch_array($username4)) {
			$ul_height = $row4['ul_height'];
			$enodeb_height = $row4['enodeb_height'];
			$propagation_model = $row4['propagation_model'];
		}
		while ($row5 = mysql_fetch_array($username5)) {
			$site_type = $row5['site_type'];
			$dimensioning_area = $row5['dimensioning_area'];
		}

		while ($row6 = mysql_fetch_array($username6)) {
			$resource_block_ul = $row6['resource_block_ul'];
			$resource_block_dl = $row6['resource_block_dl'];
			$resource_block_pucch = $row6['resource_block_pucch'];
			$propagation_loss = $row6['propagation_loss'];
			$subscriber_dl = $row6['subscriber_dl'];
			$subscriber_ul = $row6['subscriber_ul'];
			$subscriber_number = $row6['subscriber_number'];
		}
			$ul_data = $cell_edge_UL / $resource_block_ul;
			$dl_data = $cell_edge_DL / $resource_block_dl;
			$Y = ($uplink_cell_load / 100) * $ul_data * ($resource_block_ul - $resource_block_pucch);
			$Z = ($downlink_cell_load / 100) * $cell_edge_DL;
			$YY = ($Y * 3) / $subscriber_ul;
			$ZZ = ($Z * 3) / $subscriber_dl;
			$UL_SITE = $subscriber_number / $YY;
			$DL_SITE = $subscriber_number / $ZZ;
			echo "<tr>";
			echo "<td> Data Rate per resource block UL (kbps) </td>";
			echo "<td>" . $ul_data  . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Data Rate per resource block DL (kbps) </td>";
			echo "<td>" . $dl_data . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Average throughput per cell UL (kbps) </td>";
			echo "<td>" . $Y . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Average throughput per cell DL (kbps) </td>";
			echo "<td>" . $Z . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Maximum subscriber number per site UL </td>";
			echo "<td>" . $YY . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Maximum subscriber number per site DL </td>";
			echo "<td>" . $ZZ . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total Number of sites UL </td>";
			echo "<td>" . $UL_SITE . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total Number of sites DL </td>";
			echo "<td>" . $DL_SITE . "</td>";
			echo "</tr>";
			
	echo "</table>";
		mysql_close();

?>
</div>

		<footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
			<div class="footer-copyright">
				<div class="container">
					<center>
						&copy; Copyright 2016

					</center>

				</div>

			</div>
		</footer>
</body>
</html>