<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
<body style="background-image: url('images/background1.png')">
		<header class="page-header" style="background-color: rgb(45, 87, 39),">
			<div class = "container">
				<img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
				<h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
				<img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
			</div>

		</header>
	<nav id="top-menu" style="background-color:#cce; height:130px">
			<center>
			    <ul>
			        <li> <a class="btn waves-effect waves-light" href="downlink.php">Downlink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="uplink.php">Uplink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="up_down_link.php">Uplink and Downlink Capacity Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="s1_x2_solution.php">S1 and X2 dimensioning</a> </li>
			        
			    </ul>
		</center>
	</nav>
	<br><br>
	<div class="container" style="background-color:#fff" >
<?php
$site_name = $_POST['site_name'];

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT * FROM system_parameters WHERE site_name='$site_name'");
		$username1 = mysql_query("SELECT * FROM ue_parameters WHERE site_name='$site_name'");
		$username2 = mysql_query("SELECT * FROM enodeb_parameters WHERE site_name='$site_name'");	
		$username3 = mysql_query("SELECT * FROM other_parameters WHERE site_name='$site_name'");
		$username4 = mysql_query("SELECT * FROM propagation_parameters WHERE site_name='$site_name'");
		$username5 = mysql_query("SELECT * FROM coverage WHERE site_name='$site_name'");
		$username6 = mysql_query("SELECT * FROM capacity WHERE site_name='$site_name'");
		$username7 = mysql_query("SELECT * FROM s1_x2 WHERE site_name='$site_name'");

	echo "<table>";
	echo "<center> <h1> Uplink Link Budget and Coverage Calculations</h1> </center>";
		while ($row = mysql_fetch_array($username)) {
			$bandwidth = $row['bandwidth'];
			$operating_freq = $row['operating_freq'];
			$cluster_type = $row['cluster_type'];
			$cell_edge_DL = $row['cell_edge_DL'];
			$cell_edge_UL = $row['cell_edge_UL'];
			$downlink_MSC = $row['downlink_MSC'];
			$uplink_MSC = $row['uplink_MSC'];
			$channel_mode = $row['channel_mode'];
			$downlink_antenna = $row['downlink_antenna'];
			$uplink_antenna = $row['uplink_antenna'];
		}
		while ($row1 = mysql_fetch_array($username1)) {
			$ue_sensitivity = $row1['ue_sensitivity'];
			$ue_noise_figure = $row1['noise_figure'];
			$ue_control_channel = $row1['control_channel'];
			$ue_interference_margin = $row1['interference_margin'];
			$UE_tx_power = $row1['tx_power'];
			$UE_antenna_gain = $row1['antenna_gain'];
			$body_loss = $row1['body_loss'];
			$EIRP_uplink = $UE_tx_power + $UE_antenna_gain - $body_loss;
		}
		while ($row2 = mysql_fetch_array($username2)) {
			$e_tx_power = $row2['tx_power'];
			$e_antenna_gain = $row2['antenna_gain'];
			$e_enodeb_sensitivity = $row2['enodeb_sensitivity'];
			$e_noise_figure = $row2['noise_figure'];
			$e_cable_loss = $row2['cable_loss'];
			$e_interference_margin = $row2['interference_margin'];
			$e_mha_gain = $row2['mha_gain'];
			$thermal = (10 * log10(290 * 1.38*(exp(-23))* $bandwidth)) + 30;
			$receiver_noise = $thermal + $e_noise_figure;
			$EIRP_downlink = $e_tx_power + $e_antenna_gain - $e_cable_loss;
			
		}
		while ( $row3 = mysql_fetch_array($username3)) {
			$cell_edge = $row3['cell_edge'];
			$uplink_cell_load = $row3['uplink_cell_load'];
			$downlink_cell_load = $row3['downlink_cell_load'];
			$penetration_loss = $row3['penetration_loss'];
			$ul_other_gain_loss = $row3['ul_other_gain_loss'];
			$dl_other_gain_loss = $row3['dl_other_gain_loss'];
			$signal_strenght_downlink = $ue_sensitivity - $UE_antenna_gain + $e_cable_loss+ $body_loss + $dl_other_gain_loss + $ue_interference_margin;
			$signal_strenght_uplink = $e_enodeb_sensitivity - $e_antenna_gain + $e_cable_loss + $ul_other_gain_loss + $e_interference_margin;
			$MAPL = $EIRP + $e_antenna_gain + $e_mha_gain - $e_enodeb_sensitivity - $e_interference_margin - $e_cable_loss;
		}

		while ($row4 = mysql_fetch_array($username4)) {
			$ul_height = $row4['ul_height'];
			$enodeb_height = $row4['enodeb_height'];
			$propagation_model = $row4['propagation_model'];
		}
		while ($row5 = mysql_fetch_array($username5)) {
			$site_type = $row5['site_type'];
			$dimensioning_area = $row5['dimensioning_area'];
		}

		while ($row6 = mysql_fetch_array($username6)) {
			$resource_block_ul = $row6['resource_block_ul'];
			$resource_block_dl = $row6['resource_block_dl'];
			$resource_block_pucch = $row6['resource_block_pucch'];
			$propagation_loss = $row6['propagation_loss'];
			$subscriber_dl = $row6['subscriber_dl'];
			$subscriber_ul = $row6['subscriber_ul'];
			$subscriber_number = $row6['subscriber_number'];
		}

		while ($row7 = mysql_fetch_array($username7)) {
			
			$traffic_ratio_ul = $row7['traffic_ratio_ul'];
			$traffic_ratio_dl = $row7['traffic_ratio_dl'];
			$ul_bh_data_traffic = $row7['ul_bh_data_traffic'];
			$dl_bh_data_traffic = $row7['dl_bh_data_traffic'];
			$average_traffic_ratio = $row7['average_traffic_ratio'];
			$number_subscriber_enodeb = $row7['number_subscriber_enodeb'];
		}
			echo "<center> <h1> Downlink Link Budget and Coverage Calculations</h1> </center>";
			echo "<center><h1> Downlink link Budget </h1> </center>";

			echo "<tr>";
			echo "<td> Morphology </td>";
			echo "<td>" . $cluster_type . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Duplex mode </td>";
			echo "<td> FDD </td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Channel Bandwidth (MHz) </td>";
			echo "<td>" . $bandwidth . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Cell edge MCS </td>";
			echo "<td>" . $downlink_MSC . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Channel Model </td>";
			echo "<td>" . $channel_mode . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Antenna Technique </td>";
			echo "<td>" . $downlink_antenna . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Cell Edge Rate </td>";
			echo "<td>" . $cell_edge_DL . "</td>";
			echo "</tr>";

			echo "<br>";
			echo "<tr><td><center> <h1> Transmitter ~ eNodeB </h1></center></td></tr>";

			echo "<tr>";
			echo "<td> Tx Power (dBm) </td>";
			echo "<td>" . $e_tx_power . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Tx Antenna Gain (dBi) </td>";
			echo "<td>" . $e_antenna_gain. "</td>";
			echo "</tr>";
			echo "<tr>";
			//$cable_loss = $row1['cable_loss'];
			echo "<td> Total Cable loss (dB) </td>";
			echo "<td>" . $e_cable_loss . "</td>";
			echo "</tr>";
			
			echo "<tr>";
			echo "<td> EIRP (dBm)  </td>";
			echo "<td>" . $EIRP_downlink ."</td>";
			echo "</tr>";
			
			echo "<br>";
			echo "<tr><td><center> <h1> Receiver ~ UE </h1></center></td></tr>";
			//UE parameters downlink table
			echo "<tr>";
			echo "<td> Noise Figure (dB) </td>";
			echo "<td>" . $ue_noise_figure . "</td>";
			echo "</tr>";
			$thermal_downlink = (10 * log10(290 * 1.38*(exp(-23))* $bandwidth)) + 30;
			echo "<tr>";
			echo "<td> Thermal Noise Power (dBm) </td>";
			echo "<td>" . $thermal_downlink . "</td>";
			echo "</tr>";
			$receiver_noise_downlink = $thermal_downlink + $ue_noise_figure;
			echo "<tr>";
			echo "<td> Receiver Noise floor (dBm) </td>";
			echo "<td>" . $receiver_noise_downlink . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Receiver sensitivity (dBm) </td>";
			echo "<td>" . $ue_sensitivity . "</td>";
			echo "</tr>";
			$logvar = $resource_block_dl * 180000;
			$SNR_downlink = $signal_strenght_downlink + 174 - $ue_noise_figure - (10 * log10($logvar));
			echo "<tr>";
			echo "<td> SNR (dB) </td>";
			echo "<td>" .$SNR_downlink. "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Interference Margin (dB) </td>";
			echo "<td>" . $ue_interference_margin . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Control Channel Overhead (dB) </td>";
			echo "<td>" . $ue_control_channel . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Rx Antenna Gain (dBi) </td>";
			echo "<td>" . $UE_antenna_gain. "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Body Loss (dB) </td>";
			echo "<td>" . $body_loss . "</td>";
			echo "</tr>";

			$dl_other_gain_loss = $row3['dl_other_gain_loss'];
			echo "<tr>";
			echo "<td> DL other gains/losses (dB) </td>";
			echo "<td>" . $dl_other_gain_loss . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Target Load (%) </td>";
			echo "<td>" . $downlink_cell_load . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Minimum received signal strength (dBm) </td>";
			echo "<td>" . $signal_strenght_downlink. "</td>";
			echo "</tr>";
			$MAPL = $EIRP_downlink + $UE_antenna_gain - $body_loss - $ue_sensitivity - $ue_interference_margin - $ue_control_channel;
			echo "<tr>";
			echo "<td> MAPL (dB) </td>";
			echo "<td>" . $MAPL. "</td>";
			echo "</tr>";

			echo "<br> <br>";
			echo "<tr><td><center> <h1> Coverage Calculations </h1></center></td></tr>";
		
			echo "<tr>";
			echo "<td> Propagation Model </td>";
			echo "<td>" . $propagation_model . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> eNodeB height (m) </td>";
			echo "<td>" . $enodeb_height . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> UE height (m) </td>";
			echo "<td>" . $ul_height . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Frequency (MHz) </td>";
			echo "<td>" . $operating_freq . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Type of site </td>";
			echo "<td>" . $site_type . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Dimensioning area (km squared) </td>";
			echo "<td>" . $dimensioning_area . "</td>";
			echo "</tr>";
			
			
		if ($site_type == '3 sector') {
			echo "<tr>";
			echo "<td><h1>working</h1></td>";
			echo "</tr>";
			if ($cluster_type == 'Urban' || $cluster_type == 'Dense Urban') {
				$ul = 11.75 * $ul_height;
				$A = (3.2 * (log10($ul) * log10($ul))) - 4.97;
				$C = 3;
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A - $C) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((9 * sqrt(3))/8) * $R * $R;
				$P = ((3 / 2) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			elseif ($cluster_type == 'Rural' || $cluster_type == 'Suburban') {
				$A = ((1.1 * log10($operating_freq) - 0.7) * $ul_height) - (1.56 * log10($operating_freq) - 0.8);
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((9 * sqrt(3))/8) * $R * $R;
				$P = ((3 / 2) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			
		}
		elseif ($site_type == 'Omnidirectional') {
			if ($cluster_type == 'Urban' || $cluster_type == 'Dense Urban') {
				$ul = 11.75 * $ul_height;
				$A = (3.2 * (log10($ul) * log10($ul))) - 4.97;
				$C = 3;
				#echo $A;
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A - $C) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((3 * sqrt(3))/2) * $R * $R;
				$P = ((sqrt(3)) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			#elseif ($cluster_type == "Rural" || $cluster_type == "Suburban") {
			elseif ($cluster_type == 'Rural' || $cluster_type == 'Suburban') {
				echo "<tr>";
			echo "<td><h1>working Rural or Suburban</h1></td>";
			echo "</tr>";
				$A = ((1.1 * log10($operating_freq) - 0.7) * $ul_height) - (1.56 * log10($operating_freq) - 0.8);
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((3 * sqrt(3))/2) * $R * $R;
				$P = ((sqrt(3)) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			
		}

		/*
			This section of the code handles Uplink
		*/


			echo "<center> <h1> Uplink Link Budget and Coverage Calculations</h1> </center>";
			echo "<center><h1> Uplink link Budget </h1> </center>";

			echo "<tr>";
			echo "<td> Morphology </td>";
			echo "<td>" . $cluster_type . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Duplex mode </td>";
			echo "<td> FDD </td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Channel Bandwidth (MHz) </td>";
			echo "<td>" . $bandwidth . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Cell edge MCS </td>";
			echo "<td>" . $uplink_MSC . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Channel Model </td>";
			echo "<td>" . $channel_mode . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Antenna Technique </td>";
			echo "<td>" . $uplink_antenna . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Cell Edge Rate </td>";
			echo "<td>" . $cell_edge_UL . "</td>";
			echo "</tr>";


			$ul_data = $cell_edge_UL / $resource_block_ul;
			$dl_data = $cell_edge_DL / $resource_block_dl;
			$Y = ($uplink_cell_load / 100) * $ul_data * ($resource_block_ul - $resource_block_pucch);
			$Z = ($downlink_cell_load / 100) * $cell_edge_DL;
			$YY = ($Y * 3) / $subscriber_ul;
			$ZZ = ($Z * 3) / $subscriber_dl;
			$UL_SITE = $subscriber_number / $YY;
			$DL_SITE = $subscriber_number / $ZZ;
			echo "<tr>";
			echo "<td> Data Rate per resource block UL (kbps) </td>";
			echo "<td>" . $ul_data  . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Data Rate per resource block DL (kbps) </td>";
			echo "<td>" . $dl_data . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Average throughput per cell UL (kbps) </td>";
			echo "<td>" . $Y . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Average throughput per cell DL (kbps) </td>";
			echo "<td>" . $Z . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Maximum subscriber number per site UL </td>";
			echo "<td>" . $YY . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Maximum subscriber number per site DL </td>";
			echo "<td>" . $ZZ . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total Number of sites UL </td>";
			echo "<td>" . $UL_SITE . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total Number of sites DL </td>";
			echo "<td>" . $DL_SITE . "</td>";
			echo "</tr>";
			
	echo "</table>";
		mysql_close();

?>
</div>

		<footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
			<div class="footer-copyright">
				<div class="container">
					<center>
						&copy; Copyright 2016

					</center>

				</div>

			</div>
		</footer>
</body>
</html>