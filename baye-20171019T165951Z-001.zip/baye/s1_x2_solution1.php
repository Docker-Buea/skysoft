<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
<body style="background-image: url('images/background1.png')">
		<header class="page-header" style="background-color: rgb(45, 87, 39),">
			<div class = "container">
				<img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
				<h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
				<img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
			</div>

		</header>
	<nav id="top-menu" style="background-color:#cce; height:130px">
			<center>
			    <ul>
			        <li> <a class="btn waves-effect waves-light" href="downlink.php">Downlink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="uplink.php">Uplink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="up_down_link.php">Uplink and Downlink Capacity Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="s1_x2_solution.php">S1 and X2 dimensioning</a> </li>
			        
			    </ul>
		</center>
	</nav>
	<br><br>
	<div class="container" style="background-color:#fff" >
<?php
$site_name = $_POST['site_name'];

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT * FROM s1_x2 WHERE site_name='$site_name'");

	echo "<table>";
	echo "<center> <h1> S1 and X2 dimensioning</h1> </center>";
		while ($row = mysql_fetch_array($username)) {
			
			$traffic_ratio_ul = $row['traffic_ratio_ul'];
			$traffic_ratio_dl = $row['traffic_ratio_dl'];
			$ul_bh_data_traffic = $row['ul_bh_data_traffic'];
			$dl_bh_data_traffic = $row['dl_bh_data_traffic'];
			$average_traffic_ratio = $row['average_traffic_ratio'];
			$number_subscriber_enodeb = $row['number_subscriber_enodeb'];
		}
		
			$H11 = ($ul_bh_data_traffic * $traffic_ratio_ul) * 1.37 * $average_traffic_ratio * $number_subscriber_enodeb;
			$H22 = ($dl_bh_data_traffic * $traffic_ratio_dl) * 1.37 * $average_traffic_ratio * $number_subscriber_enodeb;
			$H33 = $H11 + $H22;
			$H44 = $H33 * 0.02;
			$H55 = $H33 + $H44;
			$H66 = $H55 * 0.03;
			echo "<tr>";
			echo "<td> Traffic_UL_userplane/site </td>";
			echo "<td>" . $H11  . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> raffic_DL_userplane/site </td>";
			echo "<td>" . $H22 . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total_Traffic_userplane/site </td>";
			echo "<td>" . $H33 . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total_Traffic_controlplane/site </td>";
			echo "<td>" . $H44 . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> S1 Bandwidth </td>";
			echo "<td>" . $H55 . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> X2 Bandwidth </td>";
			echo "<td>" . $H66 . "</td>";
			echo "</tr>";
			
	echo "</table>";
		mysql_close();

?>
</div>

		<footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
			<div class="footer-copyright">
				<div class="container">
					<center>
						&copy; Copyright 2016

					</center>

				</div>

			</div>
		</footer>
</body>
</html>