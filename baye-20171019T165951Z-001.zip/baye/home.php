﻿<!DOCTYPE html>
<?php
$time = time();
$date = date('F d, Y, g:i:s a');
echo $date;

?>
<html>
<head>

</head>
<body>
<span style="border:4px dashed #eac; border-radius:6px; color:#afc;width:45%;"><h1><center> WELCOME TO CRUD CONTROL CENTER </center><h1></span>
<!--
<h3>
<center>
<?php //include("links.php"); ?>
</center>
</h3>-->
<center>Please login...</center>
<center>
<form method="post" action="login.php" style="color:ada;">
<table border="0px" width="40%">
<!--id    <input type="text" name="id"/><p>-->
<tr><td width="10%">Name: </td> <td><input type="text" name="name" maxlength="25"/> </td> </tr>
<tr><td width="10%">CCN:</td> <td><input type="text" name="CCN" maxlength="10"/></td></tr>
<tr><td width="20%">Password: </td><td><input type="password" name="password" maxlength="20"/>Atleast 5 characters</td></tr>

</table>
<p>
<input type="submit" name="submit" value="Login"/><p>
<input type="reset" name="reset" value="Reset"/>
</form>
<a href="form.php">Create Account</a>
</center>
</body>
</html>