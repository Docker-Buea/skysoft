<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$ope_freq = $_POST['ope_freq'];
$bandwidth = $_POST['bandwidth'];
$cluster = $_POST['cluster'];
$DL = $_POST['DL'];
$UL = $_POST['UL'];
$downlink = $_POST['downlink'];
$uplink = $_POST['uplink'];
$channel_mode = $_POST['channel_mode'];
$DL_antenna = $_POST['DL_antenna'];
$UL_antenna = $_POST['UL_antenna'];

#mysql_connect("localhost", "root", "rolence") or die("we couldn't connect");
#mysql_select_db("baye");


if($site_name && $ope_freq && $bandwidth && $cluster && $DL && $UL && $downlink && $uplink && $channel_mode && $DL_antenna && $UL_antenna){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM system_parameters WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "Name already registered! Please type another name ";

				header("Location: system_parameters.php");

				#mysql_query("INSERT INTO system_parameters(site_name, operating_freq, bandwidth, cluster_type, cell_edge_DL, cell_edge_UL, downlink_MSC, uplink_MSC, channel_mode, downlink_antenna, uplink_antenna) VALUES('$site_name','$ope_freq','$bandwidth','$cluster','$DL','$UL','$downlink','$uplink','$channel_mode','$DL_antenna','$UL_antenna')");
				#$registered = mysql_affected_rows();
				#header("Location: user_equip.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO system_parameters(site_name, operating_freq, bandwidth, cluster_type, cell_edge_DL, cell_edge_UL, downlink_MSC, uplink_MSC, channel_mode, downlink_antenna, uplink_antenna) VALUES('$site_name','$ope_freq','$bandwidth','$cluster','$DL','$UL','$downlink','$uplink','$channel_mode','$DL_antenna','$UL_antenna')");
				$registered = mysql_affected_rows();
				header("Location: user_equip.php");
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>