<?php
session_start();
if($_POST){
$_SESSION['name'] = $_POST['name'];
$_SESSION['password'] = md5($_POST['password']);
//$name = $_POST['name'];
//$password = md5($_POST['password']);

if($_SESSION['name'] && $_SESSION['password']){
	mysql_connect("localhost:3306", "root", "rolence12") or die("we couldn't connect");
	mysql_select_db("baye");

	$query = mysql_query("SELECT * FROM user WHERE name='".$_SESSION['name']."'");
	$numrows = mysql_num_rows($query);

	if($numrows != 0){
		while($row = mysql_fetch_assoc($query)){
			$dbname = $row['name'];
			$dbpassword = $row['password'];
		}
		if($_SESSION['name'] == $dbname){
			if($_SESSION['password'] == $dbpassword){
				echo "correct password";
				header("location: profile.php");
			}else{
				echo "Your password is incorrect!";
			}
		
		}else{
			echo "Your name is not incorrect!";
		}	
	}else {
		echo "This name is not registerd!";
	}
}else{
	echo "You need to type a name and password";
}

}else{
	echo "Access denied!";
	exit;
}
?>