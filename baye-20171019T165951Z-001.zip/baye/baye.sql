-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 28, 2016 at 02:44 PM
-- Server version: 5.5.52-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `baye`
--

-- --------------------------------------------------------

--
-- Table structure for table `capacity`
--

CREATE TABLE IF NOT EXISTS `capacity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `resource_block_ul` float NOT NULL,
  `resource_block_dl` float NOT NULL,
  `resource_block_pucch` float NOT NULL,
  `subscriber_dl` float NOT NULL,
  `subscriber_ul` float NOT NULL,
  `subscriber_number` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `capacity`
--

INSERT INTO `capacity` (`id`, `site_name`, `resource_block_ul`, `resource_block_dl`, `resource_block_pucch`, `subscriber_dl`, `subscriber_ul`, `subscriber_number`) VALUES
(4, 'molyko', 87, 78, 67, 57, 45, 39),
(5, 'kumba', 34, 29, 76, 47, 86, 35),
(6, 'buea', 43, 87, 57, 86, 57, 66),
(7, 'bonaberi', 45, 76, 57, 57, 66, 76),
(8, 'akwa', 87, 68, 97, 46, 67, 56);

-- --------------------------------------------------------

--
-- Table structure for table `coverage`
--

CREATE TABLE IF NOT EXISTS `coverage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `site_type` text NOT NULL,
  `dimensioning_area` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `coverage`
--

INSERT INTO `coverage` (`id`, `site_name`, `site_type`, `dimensioning_area`) VALUES
(2, 'molyko', '3 sector', 78),
(3, 'kumba', '3 sector', 65),
(4, 'buea', 'Omnidirectional', 54),
(5, 'bonaberi', 'Omnidirectional', 76),
(6, 'akwa', 'Omnidirectional', 65);

-- --------------------------------------------------------

--
-- Table structure for table `enodeb_parameters`
--

CREATE TABLE IF NOT EXISTS `enodeb_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `tx_power` float NOT NULL,
  `antenna_gain` float NOT NULL,
  `enodeb_sensitivity` float NOT NULL,
  `noise_figure` float NOT NULL,
  `cable_loss` float NOT NULL,
  `interference_margin` float NOT NULL,
  `mha_gain` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `enodeb_parameters`
--

INSERT INTO `enodeb_parameters` (`id`, `site_name`, `tx_power`, `antenna_gain`, `enodeb_sensitivity`, `noise_figure`, `cable_loss`, `interference_margin`, `mha_gain`) VALUES
(3, 'molyko', 63, 78, 57, 87, 97, 46, 43),
(4, 'kumba', 93, 75, 87, 56, 87, 57, 45),
(5, 'buea', 45, 87, 56, 87, 56, 53, 19),
(6, 'bonaberi', 67, 86, 88, 78, 56, 76, 86),
(7, 'akwa', 48, 76, 86, 87, 76, 56, 75);

-- --------------------------------------------------------

--
-- Table structure for table `other_parameters`
--

CREATE TABLE IF NOT EXISTS `other_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `cell_edge` float NOT NULL,
  `downlink_cell_load` float NOT NULL,
  `uplink_cell_load` float NOT NULL,
  `penetration_loss` float NOT NULL,
  `dl_other_gain_loss` float NOT NULL,
  `ul_other_gain_loss` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `other_parameters`
--

INSERT INTO `other_parameters` (`id`, `site_name`, `cell_edge`, `downlink_cell_load`, `uplink_cell_load`, `penetration_loss`, `dl_other_gain_loss`, `ul_other_gain_loss`) VALUES
(4, 'molyko', 78, 97, 56, 87, 65, 97),
(5, 'kumba', 56, 56, 97, 45, 34, 39),
(6, 'buea', 56, 87, 46, 45, 98, 35),
(7, 'bonaberi', 97, 78, 56, 46, 65, 87),
(8, 'akwa', 87, 57, 57, 57, 87, 56);

-- --------------------------------------------------------

--
-- Table structure for table `propagation_parameters`
--

CREATE TABLE IF NOT EXISTS `propagation_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `ul_height` float NOT NULL,
  `enodeb_height` float NOT NULL,
  `propagation_model` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `propagation_parameters`
--

INSERT INTO `propagation_parameters` (`id`, `site_name`, `ul_height`, `enodeb_height`, `propagation_model`) VALUES
(2, 'molyko', 98, 67, 'COST231 Hata'),
(3, 'kumba', 6, 17, 'COST231 Hata'),
(4, 'buea', 3, 37, 'COST231 Hata'),
(5, 'bonaberi', 7, 56, 'Okumura Hata'),
(6, 'akwa', 76, 57, 'Okumura Hata');

-- --------------------------------------------------------

--
-- Table structure for table `s1_x2`
--

CREATE TABLE IF NOT EXISTS `s1_x2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `traffic_ratio_ul` float NOT NULL,
  `traffic_ratio_dl` float NOT NULL,
  `ul_bh_data_traffic` float NOT NULL,
  `dl_bh_data_traffic` float NOT NULL,
  `average_traffic_ratio` float NOT NULL,
  `number_subscriber_enodeb` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `s1_x2`
--

INSERT INTO `s1_x2` (`id`, `site_name`, `traffic_ratio_ul`, `traffic_ratio_dl`, `ul_bh_data_traffic`, `dl_bh_data_traffic`, `average_traffic_ratio`, `number_subscriber_enodeb`) VALUES
(1, 'molyko', 34, 87, 67, 56, 57, 76);

-- --------------------------------------------------------

--
-- Table structure for table `system_parameters`
--

CREATE TABLE IF NOT EXISTS `system_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `operating_freq` float NOT NULL,
  `bandwidth` float NOT NULL,
  `cluster_type` text NOT NULL,
  `cell_edge_DL` float NOT NULL,
  `cell_edge_UL` float NOT NULL,
  `downlink_MSC` text NOT NULL,
  `uplink_MSC` text NOT NULL,
  `channel_mode` text NOT NULL,
  `downlink_antenna` text NOT NULL,
  `uplink_antenna` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `system_parameters`
--

INSERT INTO `system_parameters` (`id`, `site_name`, `operating_freq`, `bandwidth`, `cluster_type`, `cell_edge_DL`, `cell_edge_UL`, `downlink_MSC`, `uplink_MSC`, `channel_mode`, `downlink_antenna`, `uplink_antenna`) VALUES
(14, 'molyko', 700, 1.4, 'Rural', 34, 87, '76', '57', 'EPA5', 'MIMO 2*2', 'MIMO 2*2'),
(15, 'kumba', 700, 1.4, 'Rural', 34, 34, '43', '21', 'EPA5', 'MIMO 2*2', 'MIMO 2*2'),
(16, 'buea', 1800, 10, 'Urban', 54, 64, '45', '65', 'ETU70', '2Tx-2Rx(TxDiv)', 'MIMO 2*2'),
(17, 'bonaberi', 1800, 10, 'Dense Urban', 54, 76, '55', '36', 'EPA5', 'MIMO 2*2', 'MIMO 2*2'),
(18, 'akwa', 1900, 15, 'Rural', 43, 57, '66', '87', 'EPA5', 'MIMO 2*2', 'MIMO 2*2');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  PRIMARY KEY (`id`,`site_name`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `site_name`) VALUES
(1, 'time'),
(2, 'time');

-- --------------------------------------------------------

--
-- Table structure for table `ue_parameters`
--

CREATE TABLE IF NOT EXISTS `ue_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `tx_power` int(11) NOT NULL,
  `antenna_gain` float NOT NULL,
  `ue_sensitivity` float NOT NULL,
  `body_loss` float NOT NULL,
  `noise_figure` float NOT NULL,
  `control_channel` float NOT NULL,
  `interference_margin` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `ue_parameters`
--

INSERT INTO `ue_parameters` (`id`, `site_name`, `tx_power`, `antenna_gain`, `ue_sensitivity`, `body_loss`, `noise_figure`, `control_channel`, `interference_margin`) VALUES
(3, 'molyko', 24, 46, 87, 76, 54, 76, 47),
(4, 'kumba', 24, 87, 56, 76, 45, 77, 45),
(5, 'buea', 27, 45, 87, 56, 45, 65, 54),
(6, 'bonaberi', 27, 38, 67, 987, 67, 57, 78),
(7, 'akwa', 33, 54, 87, 56, 47, 86, 29);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user`, `name`, `password`) VALUES
(1, 'camtel', 'e020590f0e18cd6053d7ae0e0a507609');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `Age` int(11) NOT NULL,
  `Hometown` text NOT NULL,
  `Job` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `FirstName`, `LastName`, `Age`, `Hometown`, `Job`) VALUES
(1, 'aka', 'rolence', 43, 'buea', 'telecom'),
(2, 'bange', 'sabastin', 32, 'tole', 'telecom');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
