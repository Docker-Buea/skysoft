<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
<body style="background-image: url('images/background1.png')">
		<header class="page-header" style="background-color: rgb(45, 87, 39),">
			<div class = "container">
				<img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
				<h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
				<img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
			</div>

		</header>
	<nav id="top-menu" style="background-color:#cce; height:130px">
			<center>
			    <ul>
			        <li> <a class="btn waves-effect waves-light" href="downlink.php">Downlink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="uplink.php">Uplink Link Budget and Coverage Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="up_down_link.php">Uplink and Downlink Capacity Calculations</a> </li>
			        <li> <a class="btn waves-effect waves-light" href="s1_x2_solution.php">S1 and X2 dimensioning</a> </li>
			        
			    </ul>
		</center>
	</nav>
	<br><br>
	<div class="container" style="background-color:#fff" >
<?php
$site_name = $_POST['site_name'];

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT * FROM system_parameters WHERE site_name='$site_name'");
		$username2 = mysql_query("SELECT * FROM enodeb_parameters WHERE site_name='$site_name'");
		$username1 = mysql_query("SELECT * FROM ue_parameters WHERE site_name='$site_name'");
		$username3 = mysql_query("SELECT * FROM other_parameters WHERE site_name='$site_name'");
		$username4 = mysql_query("SELECT * FROM propagation_parameters WHERE site_name='$site_name'");
		$username5 = mysql_query("SELECT * FROM coverage WHERE site_name='$site_name'");

	echo "<table>";
	echo "<center> <h1> Uplink Link Budget and Coverage Calculations</h1> </center>";
	echo "<center><h1> Uplink link Budget </h1> </center>";
		while ($row = mysql_fetch_array($username)) {
			$bandwidth = $row['bandwidth'];
			$operating_freq = $row['operating_freq'];
			$cluster_type = $row['cluster_type'];
			#echo $bandwidth;
			echo "<tr>";
			echo "<td> Morphology </td>";
			echo "<td>" . $row['cluster_type'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Duplex mode </td>";
			echo "<td> FDD </td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Channel Bandwidth (MHz) </td>";
			echo "<td>" . $row['bandwidth'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Cell edge MCS </td>";
			echo "<td>" . $row['uplink_MSC'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Channel Model </td>";
			echo "<td>" . $row['channel_mode'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Antenna Technique </td>";
			echo "<td>" . $row['uplink_antenna'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Cell Edge Rate </td>";
			echo "<td>" . $row['cell_edge_UL'] . "</td>";
			echo "</tr>";
			
					}
			echo "<br> <br>";
			echo "<tr><td><center> <h1> Transmitter ~ UE </h1></center></td></tr>";

		while ($row1 = mysql_fetch_array($username1)) {
			$ue_sensitivity = $row1['ue_sensitivity'];
			$ue_noise_figure = $row1['noise_figure'];
			$ue_control_channel = $row1['control_channel'];
			$ue_interference_margin = $row1['interference_margin'];
			echo "<tr>";
			$UE_tx_power = $row1['tx_power'];
			echo "<td> Tx Power (dBm) </td>";
			echo "<td>" . $row1['tx_power'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			$UE_antenna_gain = $row1['antenna_gain'];
			echo "<td> Tx Antenna Gain (dBi) </td>";
			echo "<td>" . $row1['antenna_gain'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			$body_loss = $row1['body_loss'];
			echo "<td> Body loss (dB) </td>";
			echo "<td>" . $row1['body_loss'] . "</td>";
			echo "</tr>";
			echo "<tr>";
			$EIRP = $UE_tx_power + $UE_antenna_gain - $body_loss;
			echo "<td> EIRP (dBm)  </td>";
			echo "<td>" . $EIRP ."</td>";
			echo "</tr>";
		}

			echo "<br> <br>";
			echo "<tr><td><center> <h1> Receiver ~ eNodeB </h1></center></td></tr>";
		while ($row2 = mysql_fetch_array($username2)) {
			$e_tx_power = $row2['tx_power'];
			$e_antenna_gain = $row2['antenna_gain'];
			$e_enodeb_sensitivity = $row2['enodeb_sensitivity'];
			$e_noise_figure = $row2['noise_figure'];
			$e_cable_loss = $row2['cable_loss'];
			$e_interference_margin = $row2['interference_margin'];
			$e_mha_gain = $row2['mha_gain'];
			echo "<tr>";
			echo "<td> Noise Figure (dB) </td>";
			echo "<td>" . $e_noise_figure . "</td>";
			echo "</tr>";
			$thermal = (10 * log10(290 * 1.38*(exp(-23))* $bandwidth)) + 30;
			echo "<tr>";
			echo "<td> Thermal Noise Power (dBm) </td>";
			echo "<td>" . $thermal . "</td>";
			echo "</tr>";
			$receiver_noise = $thermal + $e_noise_figure;
			echo "<tr>";
			echo "<td> Receiver Noise floor (dBm) </td>";
			echo "<td>" . $receiver_noise . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Receiver sensitivity (dBm) </td>";
			echo "<td>" . $e_enodeb_sensitivity . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> SNR (dB) </td>";
			echo "<td>" .$row['cluster_type']. "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Interference Margin (dB) </td>";
			echo "<td>" . $e_interference_margin . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Total Cable loss (dB) </td>";
			echo "<td>" . $e_cable_loss . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Rx Antenna Gain (dBi) </td>";
			echo "<td>" . $e_antenna_gain . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> MHA gain (dB) </td>";
			echo "<td>" . $e_mha_gain. "</td>";
			echo "</tr>";
		}
		while ( $row3 = mysql_fetch_array($username3)) {
			$cell_edge = $row3['cell_edge'];
			$uplink_cell_load = $row3['uplink_cell_load'];
			$downlink_cell_load = $row3['downlink_cell_load'];
			$penetration_loss = $row3['penetration_loss'];
			$ul_other_gain_loss = $row3['ul_other_gain_loss'];
			$dl_other_gain_loss = $row3['dl_other_gain_loss'];
			echo "<tr>";
			echo "<td> UL other gains/losses (dB) </td>";
			echo "<td>" . $ul_other_gain_loss . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Target Load (%) </td>";
			echo "<td>" . $uplink_cell_load . "</td>";
			echo "</tr>";
			$signal_strnght = $e_enodeb_sensitivity - $e_antenna_gain + $e_cable_loss + $ul_other_gain_loss + $e_interference_margin;
			echo "<tr>";
			echo "<td> Minimum received signal strength (dBm) </td>";
			echo "<td>" . $signal_strnght. "</td>";
			echo "</tr>";
			$MAPL = $EIRP + $e_antenna_gain + $e_mha_gain - $e_enodeb_sensitivity - $e_interference_margin - $e_cable_loss;
			echo "<tr>";
			echo "<td> MAPL (dB) </td>";
			echo "<td>" . $MAPL. "</td>";
			echo "</tr>";
		}

		echo "<br> <br>";
		echo "<tr><td><center> <h1> Coverage Calculations </h1></center></td></tr>";
		while ($row4 = mysql_fetch_array($username4)) {
			$ul_height = $row4['ul_height'];
			$enodeb_height = $row4['enodeb_height'];
			$propagation_model = $row4['propagation_model'];
		}
		while ($row5 = mysql_fetch_array($username5)) {
			$site_type = $row5['site_type'];
			$dimensioning_area = $row5['dimensioning_area'];
		}
			echo "<tr>";
			echo "<td> Propagation Model </td>";
			echo "<td>" . $propagation_model . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> eNodeB height (m) </td>";
			echo "<td>" . $enodeb_height . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> UE height (m) </td>";
			echo "<td>" . $ul_height . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Frequency (MHz) </td>";
			echo "<td>" . $operating_freq . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Type of site </td>";
			echo "<td>" . $site_type . "</td>";
			echo "</tr>";
			echo "<tr>";
			echo "<td> Dimensioning area (km squared) </td>";
			echo "<td>" . $dimensioning_area . "</td>";
			echo "</tr>";
			
			
		if ($site_type == '3 sector') {
			echo "<tr>";
			echo "<td><h1>working</h1></td>";
			echo "</tr>";
			if ($cluster_type == 'Urban' || $cluster_type == 'Dense Urban') {
				$ul = 11.75 * $ul_height;
				$A = (3.2 * (log10($ul) * log10($ul))) - 4.97;
				$C = 3;
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A - $C) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((9 * sqrt(3))/8) * $R * $R;
				$P = ((3 / 2) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			elseif ($cluster_type == 'Rural' || $cluster_type == 'Suburban') {
				$A = ((1.1 * log10($operating_freq) - 0.7) * $ul_height) - (1.56 * log10($operating_freq) - 0.8);
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((9 * sqrt(3))/8) * $R * $R;
				$P = ((3 / 2) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			
		}
		elseif ($site_type == 'Omnidirectional') {
			if ($cluster_type == 'Urban' || $cluster_type == 'Dense Urban') {
				$ul = 11.75 * $ul_height;
				$A = (3.2 * (log10($ul) * log10($ul))) - 4.97;
				$C = 3;
				#echo $A;
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A - $C) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((3 * sqrt(3))/2) * $R * $R;
				$P = ((sqrt(3)) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			#elseif ($cluster_type == "Rural" || $cluster_type == "Suburban") {
			elseif ($cluster_type == 'Rural' || $cluster_type == 'Suburban') {
				echo "<tr>";
			echo "<td><h1>working Rural or Suburban</h1></td>";
			echo "</tr>";
				$A = ((1.1 * log10($operating_freq) - 0.7) * $ul_height) - (1.56 * log10($operating_freq) - 0.8);
				$alpha = ($MAPL - 46.3 - 33.9*log10($operating_freq) + (13.82*log10($enodeb_height)) + $A) / (44.9 - (6.55 * log10($enodeb_height)));
				$R = pow(10, $alpha);
				$Q = ((3 * sqrt(3))/2) * $R * $R;
				$P = ((sqrt(3)) * $R);
				$number_site = $dimensioning_area / $Q;

				echo "<tr>";
				echo "<td> Cell radius (Km) </td>";
				echo "<td>" . $R . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Cell area (km squared) </td>";
				echo "<td>" . $Q . "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Number of sites </td>";
				echo "<td>" . $number_site. "</td>";
				echo "</tr>";

				echo "<tr>";
				echo "<td> Inter-site distance (Km) </td>";
				echo "<td>" . $P . "</td>";
				echo "</tr>";
			}
			
		}


	echo "</table>";
		mysql_close();

?>
</div>

		<footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
			<div class="footer-copyright">
				<div class="container">
					<center>
						&copy; Copyright 2016

					</center>

				</div>

			</div>
		</footer>
</body>
</html>