<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$resource_block_ul = $_POST['resource_block_ul'];
$resource_block_dl = $_POST['resource_block_dl'];
$resource_block_pucch = $_POST['resource_block_pucch'];
$subscriber_dl = $_POST['subscriber_dl'];
$subscriber_ul = $_POST['subscriber_ul'];
$subscriber_number = $_POST['subscriber_number'];


if($site_name && $resource_block_ul && $resource_block_dl && $resource_block_pucch && $subscriber_dl && $subscriber_ul && $subscriber_number){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM capacity WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "Name already registered! Please type another name ";
				header("Location: capacity.php");

				#mysql_query("INSERT INTO capacity(site_name, resource_block_ul, resource_block_dl, resource_block_pucch, propagation_loss, subscriber_dl, subscriber_ul, subscriber_number) VALUES('$site_name','$resource_block_ul','$resource_block_dl','$resource_block_pucch','$propagation_loss','$subscriber_dl','$subscriber_ul','$subscriber_number')");
				#$registered = mysql_affected_rows();
				#header("Location: other_para.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO capacity(site_name, resource_block_ul, resource_block_dl, resource_block_pucch, subscriber_dl, subscriber_ul, subscriber_number) VALUES('$site_name','$resource_block_ul','$resource_block_dl','$resource_block_pucch','$subscriber_dl','$subscriber_ul','$subscriber_number')");
				$registered = mysql_affected_rows();
				header("Location: s1_x2.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>