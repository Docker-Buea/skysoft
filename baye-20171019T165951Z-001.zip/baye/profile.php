
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
		<script src="js/jquery-2.1.1.min.js"></script>
  		<script src="js/materialize.js"></script>
  		<script src="js/init.js"></script>

  		<link rel="stylesheet" type="text/css" href="css/font_googleapis.css">
  		<link rel="stylesheet" type="text/css" href="css/materialize.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection">
  		<link rel="stylesheet" type="text/css" href="css/boostrap-theme.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
  		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css.map">
	</head>
	<body style="background-image: url('images/background1.png')">
    <header class="page-header" style="background-color: rgb(45, 87, 39),">
      <div class = "container">
        <img src="images/cam.jpg" style="witdth:45px;height:55px;margin-left:-100px">
        <h2 STYLE="color:#dCE; position:absolute; margin-top:-50px">LONG TERM EVOLUTION (LTE) 4G RAN PLANNING TOOL CAMTEL DOUALA </h2>
        <img src="images/lte.jpg" style="position:absolute;witdth:45px;height:55px; margin-left:1190px">
      </div>

    </header>
    
    <div class="container" style="border:4px #ace; border-radius:6px; background-color: #dde; color: #cae">
      <h1 >
        UNIVERSITY OF BUEA<br>
        FACULTY OF ENGINEERING AND TECHNOLOGY<br>
        Academic Internship by Cameroon Telecommunications (CAMTEL)<br>
        Bepanda, Douala-Cameroon<br>
        Project: LTE Radio And Network Planning Tool <br>
        Presented by: TABE BAIYE BISMAC<br>
        Year:      2016/2017<br>
        Technical Supervisor: Mr. Tchebe Waga Martin / Mr. Ndifor<br>
        Academic Supervisor: Mr. Achille Fumtchum<br>

      </h1>

    </div>
    <div class="container">
              
      <a class="btn waves-effect waves-light" href="system_parameters.php" style="position:left"> Next</a>
    </div>
    <footer class = "page-footer" style="background-color: rgb(52, 73, 94)">
      <div class="footer-copyright">
        <div class="container">
          <center>
            &copy; Copyright 2016

          </center>

        </div>

      </div>
    </footer>
	</body>

</html>