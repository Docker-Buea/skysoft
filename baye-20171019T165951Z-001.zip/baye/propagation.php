<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$ul_height = $_POST['ul_height'];
$enodeb_height = $_POST['enodeb_height'];
$propagation_model = $_POST['propagation_model'];


if($site_name && $ul_height && $enodeb_height && $propagation_model){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM propagation_parameters WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "The site name already exist! Please enter different site name ";
				header("Location: propagation_para.php");

				#mysql_query("INSERT INTO propagation_parameters(site_name, ul_height, enodeb_height, propagation_model) VALUES('$site_name','$ul_height','$enodeb_height','$propagation_model')");
				#$registered = mysql_affected_rows();
				#header("Location: coverage.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO propagation_parameters(site_name, ul_height, enodeb_height, propagation_model) VALUES('$site_name','$ul_height','$enodeb_height','$propagation_model')");
				$registered = mysql_affected_rows();
				header("Location: coverage.php");
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>