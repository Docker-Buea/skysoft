<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$tx_power = $_POST['tx_power'];
$antenna_gain = $_POST['antenna_gain'];
$ue_sensitivity = $_POST['ue_sensitivity'];
$body_loss = $_POST['body_loss'];
$noise_figure = $_POST['noise_figure'];
$ue_gain = $_POST['ue_gain'];
$interference_margin = $_POST['interference_margin'];


if($site_name && $tx_power && $antenna_gain && $ue_sensitivity && $body_loss && $noise_figure && $ue_gain && $interference_margin){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM ue_parameters WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "Name already registered! Please type another name ";
				header("Location: user_equip.php");

				#mysql_query("INSERT INTO ue_parameters(site_name, tx_power, antenna_gain, ue_sensitivity, body_loss, noise_figure, control_channel, interference_margin) VALUES('$site_name','$tx_power','$antenna_gain','$ue_sensitivity','$body_loss','$noise_figure','$ue_gain','$interference_margin')");
				#$registered = mysql_affected_rows();
				#header("Location: enodeB_para.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO ue_parameters(site_name, tx_power, antenna_gain, ue_sensitivity, body_loss, noise_figure, control_channel, interference_margin) VALUES('$site_name','$tx_power','$antenna_gain','$ue_sensitivity','$body_loss','$noise_figure','$ue_gain','$interference_margin')");
				$registered = mysql_affected_rows();
				header("Location: enodeB_para.php");
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>