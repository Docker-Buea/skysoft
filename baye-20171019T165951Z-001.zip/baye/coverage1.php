<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$site_name = $_POST['site_name'];
$site_type = $_POST['site_type'];
$dimensioning_area = $_POST['dimensioning_area'];


if($site_name && $site_type && $dimensioning_area ){

		mysql_connect("localhost", "root", "rolence12") or die("we couldn't connect");
		mysql_select_db("baye");
		$username = mysql_query("SELECT site_name FROM coverage WHERE site_name='$site_name'");
		$count = mysql_num_rows($username);

			if($count != 0){
				
				echo "Name already registered! Please type another name";
				header("Location: coverage.php");

				#mysql_query("INSERT INTO coverage(site_name, site_type, dimensioning_area) VALUES('$site_name','$site_type','$dimensioning_area')");
				#$registered = mysql_affected_rows();
				#header("Location: capacity.php");
				#echo "$registered was successful <a href='user_equip.php'></a>";
		
			}else{
				mysql_query("INSERT INTO coverage(site_name, site_type, dimensioning_area) VALUES('$site_name','$site_type','$dimensioning_area')");
				$registered = mysql_affected_rows();
				header("Location: capacity.php");
		}
		mysql_close();
}else{
echo "Fill the form completely!";
}
?>
</body>
</html>